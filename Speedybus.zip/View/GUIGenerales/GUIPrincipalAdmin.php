<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>Sistema Administrador</title>
</head>
<body>
	<!--Header-->
	<header id="header">
		<!--Logo-->
		<div id="logo">
			<a href="GUIPrincipalAdmin.php">SpeedyBus</a>
		</div>

		<!--Menu-->
		<nav>
			<ul>
				<li>
					<a href="GUIPrincipalAdmin.php">Información</a>
				</li>
				<li>
					<a href="GUIPrincipalAdmin.php">Promociones</a>
				</li>
				<li>
					<a href="GUIPrincipalAdmin.php">Autobuses</a>
				</li>
				<li>
					<a href="GUIPrincipalAdmin.php">Horarios</a>
				</li>
				<li>
					<a href="GUIPrincipalAdmin.php">Viajes Normales</a>
				</li>
				<li>
					<a href="GUIPrincipalAdmin.php">Paquetes De Viaje</a>
				</li>
				<li>
					<a href="GUIPrincipalAdmin.php">Viajes De Renta</a>
				</li>
			</ul>
		</nav>

	</header>

</body>
</html>