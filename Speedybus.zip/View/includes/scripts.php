<!-- <script src="View/js/jquery.slim.min.js"></script> -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="Resources/js/popper.min.js"></script>
<script src="Resources/js/bootstrap.min.js"></script>
<script src="Resources/js/app.js"></script>